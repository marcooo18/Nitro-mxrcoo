import random
import string
import colorama
from colorama import Fore
import os
import time
import requests
import threading
from queue import Queue, Empty
from datetime import datetime

colorama.init()

class GradientPrinter:
    def __init__(self, start_color=(128, 0, 255), end_color=(0, 0, 255), steps=10):
        self.start_color = start_color
        self.end_color = end_color
        self.steps = steps
        self.colors = self._generate_gradient()

    def _generate_gradient(self):
        r_step = (self.end_color[0] - self.start_color[0]) / self.steps
        g_step = (self.end_color[1] - self.start_color[1]) / self.steps
        b_step = (self.end_color[2] - self.start_color[2]) / self.steps
        return [
            (
                int(self.start_color[0] + r_step * i),
                int(self.start_color[1] + g_step * i),
                int(self.start_color[2] + b_step * i)
            ) for i in range(self.steps)
        ]

    def print(self, text):
        lines = text.split('\n')
        for i, line in enumerate(lines):
            color = self.colors[min(i, len(self.colors) - 1)]
            print(f"\033[38;2;{color[0]};{color[1]};{color[2]}m{line.center(os.get_terminal_size().columns)}\033[0m")

def clear_screen(title="Nitro Gen V2"):
    os.system('cls' if os.name == 'nt' else 'clear')
    if os.name == 'nt':
        os.system(f'title {title}')

def print_banner():
    banner = """
   ███▄    █  ██▓▄▄▄█████▓ ██▀███   ▒█████       ▄████ ▓█████  ███▄    █    
   ██ ▀█   █ ▓██▒▓  ██▒ ▓▒▓██ ▒ ██▒▒██▒  ██▒    ██▒ ▀█▒▓█   ▀  ██ ▀█   █    
  ▓██  ▀█ ██▒▒██▒▒ ▓██░ ▒░▓██ ░▄█ ▒▒██░  ██▒   ▒██░▄▄▄░▒███   ▓██  ▀█ ██▒   
  ▓██▒  ▐▌██▒░██░░ ▓██▓ ░ ▒██▀▀█▄  ▒██   ██░   ░▓█  ██▓▒▓█  ▄ ▓██▒  ▐▌██▒   
  ▒██░   ▓██░░██░  ▒██▒ ░ ░██▓ ▒██▒░ ████▓▒░   ░▒▓███▀▒░▒████▒▒██░   ▓██░   
  ░ ▒░   ▒ ▒ ░▓    ▒ ░░   ░ ▒▓ ░▒▓░░ ▒░▒░▒░     ░▒   ▒ ░░ ▒░ ░░ ▒░   ▒ ▒    
  ░ ░░   ░ ▒░ ▒ ░    ░      ░▒ ░ ▒░  ░ ▒ ▒░      ░   ░  ░ ░  ░░ ░░   ░ ▒░   
     ░   ░ ░  ▒ ░  ░        ░░   ░ ░ ░ ░ ▒     ░ ░   ░    ░      ░   ░ ░    
"""
    gradient_printer = GradientPrinter(start_color=(255, 0, 255), end_color=(0, 0, 255), steps=10)
    gradient_printer.print(banner)
    gradient_printer.print("Nitro Gen-mxrcoo")

def generate_gift_code():
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(16))

def check_nitro_code(code):
    nitro_url = f"https://discord.com/api/v9/entitlements/gift-codes/{code}?with_application=false&with_subscription_plan=true"
    try:
        response = requests.get(nitro_url, timeout=5)
        if response.status_code == 200:
            return True
        elif response.status_code == 429:  # Rate limited
            retry_after = response.json().get("retry_after", 1)
            print(Fore.YELLOW + f"[RATE LIMIT] Retrying after {retry_after} seconds..." + Fore.RESET)
            time.sleep(retry_after)
        return False
    except requests.RequestException as e:
        print(Fore.RED + f"[ERROR] Nitro check failed: {e}" + Fore.RESET)
        return False

def send_webhook_message(webhook_url, message):
    data = {"content": message}
    try:
        response = requests.post(webhook_url, json=data, timeout=5)
        if response.status_code != 204:
            print(Fore.RED + f"[ERROR] Webhook response error: {response.status_code}" + Fore.RESET)
    except requests.RequestException as e:
        print(Fore.RED + f"[ERROR] Failed to send webhook message: {e}" + Fore.RESET)

def worker(webhook_url, queue, stop_event):
    while not stop_event.is_set():
        try:
            gift_code = queue.get(timeout=0.1)
        except Empty:
            continue
        nitro_link = f"https://discord.gift/{gift_code}"
        if check_nitro_code(gift_code):
            print(Fore.GREEN + f'[VALID] Nitro Gift Link: {nitro_link}' + Fore.RESET)
            send_webhook_message(webhook_url, f"Valid Nitro Gift Link found: {nitro_link}")
        else:
            print(Fore.RED + f'[INVALID] Nitro Gift Link: {nitro_link}' + Fore.RESET)
        queue.task_done()

def wait_for_enter(stop_event):
    input(Fore.YELLOW + "Press Enter to stop the tool.\n" + Fore.RESET)
    stop_event.set()

def verify_webhook(webhook_url):
    try:
        response = requests.get(webhook_url, timeout=5)
        if response.status_code == 200:
            data = response.json()
            name = data.get("name", "Unknown")
            created_at = datetime.fromtimestamp(((int(data["id"]) >> 22) + 1420070400000) / 1000)
            creator = data.get("user", {}).get("username", "Unknown")
            return True, {
                "name": name,
                "created_at": created_at.strftime("%Y-%m-%d %H:%M:%S"),
                "creator": creator
            }
        else:
            return False, None
    except requests.RequestException as e:
        print(Fore.RED + f"[ERROR] Webhook verification failed: {e}" + Fore.RESET)
        return False, None

def main():
    clear_screen()
    print_banner()

    while True:
        print("")
        print("")
        webhook_url = input(Fore.BLUE + "Please enter the webhook URL: " + Fore.RESET).strip()
        if not webhook_url:
            print(Fore.RED + "[ERROR] Webhook URL cannot be empty. Please try again." + Fore.RESET)
            time.sleep(2)
            clear_screen()
            print_banner()
            continue

        print(Fore.YELLOW + "Verifying webhook URL..." + Fore.RESET)
        valid, details = verify_webhook(webhook_url)
        if not valid:
            print(Fore.RED + "[ERROR] Invalid Webhook URL. Returning to menu in 2 seconds..." + Fore.RESET)
            time.sleep(2)
            clear_screen()
            print_banner()
            continue

        print(Fore.GREEN + f"Webhook Information:\n"
                           f"  - Name: {details['name']}\n"
                           f"  - Created At: {details['created_at']}\n"
                           f"  - Creator: {details['creator']}\n" + Fore.RESET)
        confirm = input(Fore.YELLOW + "Are these details correct? (y/n): " + Fore.RESET).lower()
        if confirm == 'y':
            break
        else:
            print(Fore.CYAN + "Returning to menu...\n" + Fore.RESET)
            time.sleep(2)
            clear_screen()
            print_banner()

    print(Fore.YELLOW + "Please wait for 2 seconds before starting the tool..." + Fore.RESET)
    time.sleep(2)

    queue = Queue()
    num_threads = 25
    stop_event = threading.Event()

    threads = [threading.Thread(target=worker, args=(webhook_url, queue, stop_event)) for _ in range(num_threads)]
    for t in threads:
        t.start()

    exit_thread = threading.Thread(target=wait_for_enter, args=(stop_event,))
    exit_thread.start()

    try:
        while not stop_event.is_set():
            gift_code = generate_gift_code()
            queue.put(gift_code)
    except KeyboardInterrupt:
        stop_event.set()
    finally:
        for t in threads:
            t.join()
        exit_thread.join()

    print(Fore.YELLOW + "[Tool_Message] Tool exited gracefully." + Fore.RESET)

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(Fore.RED + f"[FATAL ERROR] {e}" + Fore.RESET)
